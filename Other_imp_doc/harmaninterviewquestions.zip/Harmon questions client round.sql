		-------Harman Interview -------
1-About project
2- diffrence between derived and cte
3- diffrence between proc and veiw
4- deiffrence between proc and fucntion
5- what is dynamic sql 
6- what is trigger and types of trigger
7- Index and type of indexes
8- two table emp and dept 
-max salery in each department
-max salery of empoyee name and detail in each dept
-employee and their manager name
8-
tab1			tab2
col1			col2
1				1
1				1
1
null

result set of all type of join 

9- diffrence b/w primary and unique key

-----		second round -------

1- about project 
2- diffrence b/w derived and cte
3- types of indexes
4- How you will imporve proc performace 
5- dynamic sql
6- how you will apply index col in querry where claues way to write querry on index column

7- tab1									tab2
	name  id  age phone 			name id age phone
	A		1	23	9876
	
	
requeirment date is not in tab2 insert and if data is there and any col value is change then update it and if any data is in tab2 but not in tab1 delete
in single querry

8-	record						table name and  record 
	id		name 				ic800	1000
	800		a					ic900	8000
	900		b					ic1000	1200
	1000	c
	
	Final_table 
	id 		total_row_count
	800		1000
	900		8000
	1000	1200
	
9- 
Three method to remove duplicate record 



----------client round ------

1- about project
2- where you have created index in your project and how it was imporving performance
3-how you will imporve querry performace
4- how index works and why one clustered index in a table 
5- what is composite index and what is its property , if we filter condition on only columnB and composite index on columnA and ColumnB so columnB will touch index or not 
6-where index use in querry and suppose we have join condition of two table so in that case will it touch index or not explanation .
7- Did you use any other tool leaving sql profiler , and how you  will take report of your querry performance in csv file .
8-how you will handle error and what key word you will use to handly error. 
9-what is role of lockon table in performance tunning
10-how you will check performace before running querry .
11- if you have created stored procedure before 3 year and now you are going compile that stored procedure will exection plan will be same or change .


	
	
	
	
	